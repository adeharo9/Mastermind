package exceptions;

public class IntegrityCorruptionException extends AbstractException
{
}
