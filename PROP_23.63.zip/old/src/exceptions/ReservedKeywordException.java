package exceptions;

public class ReservedKeywordException extends AbstractException
{

}
