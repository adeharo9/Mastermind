package exceptions;

public class GameNotStartedException extends AbstractException
{
}
