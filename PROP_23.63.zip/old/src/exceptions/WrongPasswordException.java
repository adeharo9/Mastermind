package exceptions;

public class WrongPasswordException extends AbstractException
{

}
