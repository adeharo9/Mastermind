package exceptions;

public class IllegalActionException extends AbstractException
{
    public IllegalActionException()
    {

    }

    public IllegalActionException(final String msg)
    {
        super(msg);
    }
}
