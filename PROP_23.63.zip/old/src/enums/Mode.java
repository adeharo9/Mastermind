package enums;

public enum Mode
{
    HUMAN_VS_HUMAN,
    HUMAN_VS_CPU,
    CPU_VS_CPU,
}
