package enums;

import java.io.Serializable;

public enum Difficulty implements Serializable
{
    EASY,
    MEDIUM,
    HARD,
}
