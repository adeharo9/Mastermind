package testing.stubs;

public class StubPresentationController {
    public void clear(){}
}
