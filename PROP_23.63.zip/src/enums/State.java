package enums;

/**
 * enum State.
 *
 * Estados del programa.
 *
 * @author Alejandro de Haro
 */

public enum State
{
    HINT_MENU,

    CHECK_GAME_HAS_FINISHED,
    INFO_MENU,
    RANKING_MENU,
    CLOSE_PROGRAM,
    CLOSE_PROGRAM_WARNING,
    CONTINUE_GAME,

    EDIT_USER_MENU,
    EDIT_USERNAME,
    EDIT_PASSWORD,
    EXIT_CURRENT_GAME,
    EXIT_CURRENT_GAME_WARNING,

    NEW_GAME_MENU,
    GAME_OVER_MENU,
    GAME_PAUSE_MENU,

    INIT_PROGRAM,
    INIT_SESSION_MENU,

    LAST_ACTIONS,
    LOAD_GAME,
    LOAD_GAME_MENU,
    DELETE_GAME,
    LOAD_RANKING,
    LOG_IN_MENU,
    LOG_IN_USER,
    LOG_OUT_WARNING,

    MAIN_MENU,

    NEW_GAME,

    PLAY_TURN,
    PLAY_CODE_BREAKER,
    PLAY_CODE_CORRECTER,
    PLAY_CODE_MAKER,

    REGISTER_MENU,
    REGISTER_USER,
    RENDER_BOARD,
    RESTART_GAME,

    SAVE_GAME,
    SAVE_GAME_MENU,
    SAVE_GAME_OVERWRITE_MENU,
}